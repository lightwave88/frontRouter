'use strict';

debugger;

import $GM from './g_module.js';
import { config } from './config.js';
import getAnalyze_factory from './signalAnalyze/signalAnalyze.js';
import router_factory from './router.js';

$GM.load('config', config);
$GM.load('getAnalyze', getAnalyze_factory($GM));
$GM.load('router', router_factory($GM));

//---------------------------------

function factory(gm) {
  debugger;
  // 從上一層注入 tools
  $GM.setParent(gm);

  const router = $GM.get('router');
  return router;
}
// debugger;
export default factory;
