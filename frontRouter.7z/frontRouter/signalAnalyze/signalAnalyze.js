'use strict';

let $GM;

const $REG_1 = /\/|\\|\^|\$|\(|\)|\[|\]|\{|\}|\.|\*|\+|\?|\|/;
const $REG_2 = /^\*$/;

class Interface {

  // [path, query, hash]
  $source;

  $dataFormat;

  $baseUrlData = {
    pathname: null,
    search: null,
    origin: null,
    hash: null,
  };

  $router;

  $locationData;
  //------------------------------------------------
  constructor(options = {}) {
    // debugger;

    let { source, router } = options;

    this.$source = source;
    this.$router = router;

    const router_attrs = router['$$$attrs']

    Object.assign(this.$baseUrlData, router_attrs.baseUrlData);
  }
  //------------------------------------------------
  get dataFormat(){
    return this.$dataFormat;
  }
  //------------------------------------------------
  // 根據設定傳回 locationData
  getUrlData() { }
  //------------------------------------------------
  // 根據信號去判讀 Router 規則是否成立
  checkRouterItem() { }
  //------------------------------------------------
  // 若規則成立，取出參數
  getParam() {
    // 根據 $baseUrlData 來設定
  }
  //------------------------------------------------
  // onPopState 事件,router 必須更新
  setLocationData(event, data) { }
  //------------------------------------------------
  string2RegExpEscape(str) {
    const reg_1 = RegExp($REG_1, 'g');
    str = str.replace(reg_1, (m) => {
      return '\\' + m;
    });
    return str;
  }
}
////////////////////////////////////////////////////////////////////////////////

class KeywordType extends Interface {

  $dataFormat = 'keyword';

  // 比較規則
  $checkValue = { str: null, reg: null };

  //------------------------------------------------
  constructor(options) {
    super(options);
  }
  //------------------------------------------------
  // 根據設定傳回 locationData
  getUrlData() { }
  //------------------------------------------------
  // 根據信號去判讀 Router 規則是否成立
  checkRouterItem(item) {
    // debugger;
    // 檢測結果
    let res;

    if(!(this.$source in item)){
      throw new Error(`router no key(${this.$source})`);
    }
    // 取得 item 的設定
    let ruleValue = item[this.$source];

    const { str, reg } = this.$checkValue;

    // debugger;

    if (ruleValue instanceof RegExp) {
      res = ruleValue.test(str);
    } else if (typeof ruleValue == 'string') {

      if($REG_2.test(ruleValue)){
        // "*" 不用比對
        res = true;
      }else{
        res = reg.test(ruleValue);
      }
    }
    return res;
  }
  //------------------------------------------------
  // 若規則成立，取出參數
  getParam() {

  }
  //------------------------------------------------
  setLocationData(event, locationData) {
    debugger;

    let signalValue;

    switch (this.$source) {
      case 'hash':
        signalValue = locationData.hash;
        break;
      default:
        throw new Error('keyword 只適合 hash');
    }

    let reg = this.string2RegExpEscape(signalValue);
    reg = RegExp(`^${reg}$`);

    this.$checkValue = {
      str: signalValue,
      reg,
    }
  }
}
////////////////////////////////////////////////////////////////////////////////
class QueryType extends Interface {

  $dataFormat = 'query';

  constructor(options) {
    super(options);
  }
}
////////////////////////////////////////////////////////////////////////////////
class PathType extends Interface {

  $dataFormat = 'path';

  constructor(options) {
    super(options);
  }
}
////////////////////////////////////////////////////////////////////////////////

function getAnalyze(router, dataFormat, source) {
  // debugger;
  let analyze;

  const arg = {source, router};

  switch (dataFormat) {
    case 'path':
      analyze = new PathType(arg);
      break;
    case 'query':
      analyze = new QueryType(arg);
      break;
    case 'keyword':
      analyze = new KeywordType(arg);
      break;
    default:
      throw new TypeError();
  }
  return analyze;
}


function factory(gm) {
  $GM = gm;
  return getAnalyze;
}

export default factory;
