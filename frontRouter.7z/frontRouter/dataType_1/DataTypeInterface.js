// debugger;

class DataTypeInterface {

  router;
  //----------------------------------------------------------------------------
  constructor(router) {
    this.router = router;
  }
  //----------------------------------------------------------------------------
  // @override
  // 加入 router 規則的方式
  addRoutes() {
  }
  //----------------------------------------------------------------------------
  // @override
  // router.push()|router.replace()
  // 時取得對映的 url
  // 把簡易路徑解析成 絕對路徑
  getUrl() {
  }
  //----------------------------------------------------------------------------
  // @override
  // 由 event.popstate 呼叫
  // 解析當收到 event.popstate 的方式
  popstate(data = {}) {
  }
  //----------------------------------------------------------------------------

}

export default DataTypeInterface;
export { DataTypeInterface };