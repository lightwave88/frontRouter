'use strict';

class RuleItem {

  // 要檢視的信號列表
  $checkList = {};
  $callback;
  //------------------------------------------------
  constructor(signalSetting = {}, setting = {}) {

    let { callback } = setting;
    this.$callback = callback;
    //------------------
    for (let key in signalSetting) {
      if (setting[key] == null) {

        // 缺少某個訊號的設定
        throw new Error(`缺少對信號(${key})的設定`);
      }
      $checkList[key] = setting[key];
    }
  }
  //------------------------------------------------
  // 取出要的信號來做比較
  getRule(sourceName) {
    let value = (this.$checkList[sourceName] == null ? null : this.$checkList[sourceName]);
    return value;
  }
}

export { RuleItem };
