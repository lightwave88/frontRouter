// debugger;
const $REG_1 = /^#/;


const factory = function (InterFace, $GM) {
  debugger;


  class KeywordType extends InterFace {

    $routes = [];

    //--------------------------------------------------------------------------
    constructor(router) {
      super(router);
    }
    //--------------------------------------------------------------------------
    addRoutes(list = []) {
      this.$routes = this.$routes.concat(list);
    }
    //--------------------------------------------------------------------------
    // router.push()|router.replace()
    // 時取得對映的 url
    getUrl(keyword) {
      let location = window.location;

      if (!$REG_1.test(keyword)) {
        throw new TypeError('...');
      }

      let url = location.pathname + location.search + keyword;
      return url;
    }
    //--------------------------------------------------------------------------
    // 由 event.popstate 呼叫
    // 解析當收到 event.popstate 的方式
    popstate(data = {}) {
      debugger;

      const { router, location } = data;

      // 信號的來源
      // [path|query|hash]
      let source = router.$source;

      // 訊號
      let signal;

      // 根據訊號來源來取得資訊
      // keyword 只適合 hash 模式
      switch (source) {
        case 'hash':
          // 只支援 hash 的訊號
          signal = location.hash;
          signal = signal.slice(1);
          break;
        default:
          throw new TypeError(`no support source(${source})`);
          break;
      }
      //------------------
      let callbackName = this._checkRoutes(signal);

      this.router.$fn.execute(this.router, callbackName, [signal]);;
    }
    //--------------------------------------------------------------------------
    _checkRoutes(signal) {
      debugger;

      let routes = this.$routes.slice();

      let res = null;
      let allMatch = null;

      routes.some((d) => {
        debugger;

        let { hash, callback } = d;

        if (hash === '*') {
          allMatch = callback;
          return;
        }

        if (hash === signal) {
          res = callback;
          return true;
        }
      });

      if (res == null && allMatch != null) {
        // 若沒有匹配，那是否有全部匹配
        res = allMatch;
      }

      return res;
    }
  }

  //----------------------------------------------------------------------------
  return KeywordType;
}

export default factory;
