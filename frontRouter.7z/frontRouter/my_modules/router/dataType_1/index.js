// debugger;

import { DataTypeInterface } from './interface.js';
import keywordType_factory from './keywordType.js';


export default function (gm) {
	// debugger;

  const KeywordType = keywordType_factory(DataTypeInterface, gm);

  return {
    DataTypeInterface,
    KeywordType,
  };
};
