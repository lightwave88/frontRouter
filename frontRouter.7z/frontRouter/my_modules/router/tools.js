// debugger;

const $tools = {};

export default $tools;

$tools.isPlainObject = (() => {
	// from jquery
	const reg_1 = /^\[object Object\]$/;

	const proto_tooString = Object.prototype.toString;
	const class2type = {};
	const class2typeCts = {}.constructor;
	const hasOwn = class2type.hasOwnProperty;

	return function (obj) {
		// debugger;
		let proto, Ctor, res;

		if (typeof obj != 'object') {
			return false;
		}

		// Detect obvious negatives
		// Use toString instead of jQuery.type to catch host objects
		res = proto_tooString.call(obj);
		res = reg_1.test(res);

		if (!obj || !res) {
			return false;
		}

		proto = Object.getPrototypeOf(obj);

		// Objects with no prototype (e.g., `Object.create( null )`) are plain
		if (!proto) {
			return true;
		}

		// Objects with prototype are plain iff they were constructed by a global Object function
		Ctor = hasOwn.call(proto, "constructor") && proto.constructor;

		return (typeof Ctor == "function" && Ctor === class2typeCts);
	}
})();
