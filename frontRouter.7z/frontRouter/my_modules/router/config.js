
const config = {

  // router 的辨別模式
  dataFormat: ['path', 'query', 'keyword'],

  // 訊號來源
  inputSource: ['url', 'query', 'hash'],

  sourceFormats: {
    url: ['path'],
    // query.path: ?path = .../.../
    query: ['path', 'query'],
    // hash.path = #.../.../
    hash: ['path', 'query', 'keyword'],
  }
}

export { config };