// debugger;

let $GM;

// API
function router(blueprint, options = {}) {
  return new RouterInstance(blueprint, options);
};

export default function (gm) {
  $GM = gm;
  return router;
}
////////////////////////////////////////////////////////////////////////////////

let $UID = 0;

// cache
const $locationKeys = [];
const $REG_1 = /(#)|(\?)/;
const $REG_2 = /^https?:\/\/[^/]*/;
const $REG_3 = /^callback$/;
const $REG_4 = /^\*$/;

class RouterInstance {

  // 屬性
  // 避免被覆蓋
  $$$attrs = {
    id: null,
    // 信號種類=分析器
    analyzes: {},
    baseUrlData: {
      pathname: null,
      hash: null,
      origin: null,
      search: null,
    },
    // 使用者設定的 routers 規則
    routerList: [],
    noMatchRoute: null,
    eventCallback: null,
    // 是否只取一個匹配
    unique: true,
    syncJob: null,
    event,
  };
  //----------------------------------------------------------------------------
  // blueprint: [{}|[{},{}...]] 可以有 mixin
  constructor(blueprint, options = {}) {
    // debugger;

    const selfAttrs = this['$$$attrs'];
    let routes = [];

    selfAttrs.id = `router_${$UID++}`;

    let blueprints = [];
    //------------------
    if (Array.isArray(blueprint)) {
      blueprints = blueprint;
    } else {
      blueprints.push(blueprint);
    }

    let _blueprint = {};

    blueprints.forEach((item) => {
      // debugger;
      if ('options' in item) {
        Object.assign(options, item.options,);
        delete item.options;
      }

      if ('routes' in item) {
        let _routes = item.routes;
        delete item.routes;
        routes = routes.concat(_routes);
      }
      Object.assign(_blueprint, item);
    });
    //------------------
    // debugger;
    // options
    // 有設置 format, source 就不用設置 sourceFormat
    let {
      // type: []
      sourceFormat = null,
      baseUrl = null,
    } = options;
    //------------------
    let urlData;
    if (baseUrl != null) {
      // 若有指定 baseUrl
      urlData = checkBaseUrl(baseUrl);
    } else {
      // 若沒指定 baseUrl
      urlData = checkBaseUrl(getLocationData());
    }
    Object.assign(selfAttrs.baseUrlData, urlData);
    //------------------
    mergeObj(this, _blueprint);
    //------------------
    // 確定信號來源與格式
    if (sourceFormat == null) {
      throw new Error('no set sourceFormat');
    }

    // 確定信號與資料格式的配對
    this.setSourceForamt(sourceFormat);

    // debugger;
    // 必須位於 this.setSourceForamt
    // 才知道有哪些信號源要檢查
    this.setRoutes(routes);
    //------------------
    // debugger;

    window.addEventListener('popstate', this.eventChange);
    window.addEventListener('hashchange', this.eventChange);
  }
  //----------------------------------------------------------------------------
  // 傾聽 window.popstate 的 callback
  get eventChange() {
    debugger;
    const attrs = this.$$$attrs;

    if (attrs.eventCallback == null) {

      attrs.eventCallback = (e) => {
        debugger;

        if (attrs.event == null || attrs.event instanceof HashChangeEvent) {
          // e 以 PopStateEvent 爲主 
          attrs.event = e;
        }

        if (attrs.syncJob == null) {
          attrs.syncJob = getSyncJob(this);
        }
      }
    }
    return attrs.eventCallback;
  }
  //----------------------------------------------------------------------------
  // 可以設置多種信號來源
  setSourceForamt(source, format = null) {

    const $config = $GM.get('config');
    const { dataFormat, inputSource } = $config;

    const $tools = $GM.get('tools');

    const getAnalyze = $GM.get('getAnalyze');

    let settings = {};

    if (!$tools.isPlainObject(source)) {
      settings[source] = format;
    } else {
      Object.assign(settings, source);
    }

    const { analyzes } = this.$$$attrs;

    // 輸入檢查
    for (let sr in settings) {
      // debugger;
      const _dataFormat = settings[sr];

      // 檢查輸入
      if (!dataFormat.includes(_dataFormat)) {
        throw new TypeError(`not this format(${_dataFormat})`);
      }

      if (!inputSource.includes(sr)) {
        throw new TypeError(`not this input(${sr})`);
      }
      // debugger;
      // 決定解析器
      const analyze = getAnalyze(this, _dataFormat, sr);
      analyzes[sr] = analyze;
    }

    return this;
  }
  //----------------------------------------------------------------------------
  // 設定 router 規則
  setRoutes(list = []) {

    list.forEach((item) => {
      this.addRoute(item);
    });

    return this;
  }
  //----------------------------------------------------------------------------
  // 加入規矩
  addRoute(data = {}) {
    // debugger;

    const attrs = this['$$$attrs'];

    const checkSourceList = Object.keys(attrs.analyzes);
    if (!checkSourceList.length) {
      throw new Error('no set sourceFormat');
    }

    // 爲了找出 noMatchRoute
    let checkCount = 0;
    let matchCount = 0;
    let callback;

    // 檢查輸入
    for (let key in data) {
      // debugger;

      let format = data[key];

      if ($REG_3.test(key)) {
        // is callback 不需檢查
        callback = format;
        continue;
      }
      //------------------
      if (!checkSourceList.includes(key)) {
        throw new Error(`...`);
      }

      if (typeof (format) == 'string' && $REG_4.test(format)) {
        // format == "*"
        matchCount++;
      }

      checkCount++;
    } // endLoop

    // debugger;
    if (callback == null) {
      throw new Error(`route no set callback`);
    }

    if (typeof callback == 'string') {
      if (typeof this[callback] != 'function') {
        throw new Error(`no this callback(${callback})`);
      }
      callback = this[callback].bind(this);
    }

    if (checkCount == 0) {
      throw new Error(`no set souruce `);
    } else if (checkCount == matchCount) {
      attrs.noMatchRoute = callback;
      return;
    }

    data.callback = callback;
    attrs.routerList.push(data);

    return this;
  }
  //----------------------------------------------------------------------------
  // 前往新頁面，有歷史記憶
  // overrideAll 覆蓋所有的值
  //
  // push(singalName, data, true)
  //
  // push({
  //  singalName: [data, overrideAll],
  //  singalName: data
  // })

  push(singalName, data, overrideAll = true) {
    // 從 $analyze 取得 url

    return this;
  }
  //----------------------------------------------------------------------------
  // 前往新頁面，沒有歷史記憶
  replace(path, data) {
    // 從 $analyze 取得 url
    let url = this.$analyze.getUrl();

    return this;
  }
  //----------------------------------------------------------------------------

}

////////////////////////////////////////////////////////////////////////////////
// 當收到 window.popstate 事件
// 要確定哪些 rules 合乎條件
function checkRouters(e) {
  debugger;

  const $this = this;
  const attrs = $this['$$$attrs'];
  const { routerList, analyzes } = attrs;

  // 有關於 location 的 data
  let locationData = getLocationData();

  for (let key in analyzes) {
    const analyze = analyzes[key];
    analyze.setLocationData(e, locationData);
  }
  debugger;
  //------------------
  // rules
  let j = 0;
  out: for (let i = 0; i < routerList.length; i++) {
    debugger;

    const routerItem = routerList[i];

    for (let sourceName in analyzes) {
      debugger;

      // 檢查信號
      const analyze = analyzes[sourceName];
      // 檢查規則
      const res = analyze.checkRouterItem(routerItem);

      if (res !== true) {
        continue out;
      }
    } // endLoop
    //-------------
    j++;
    const fn = routerItem.callback;
    fn();

    if (attrs.unique) {
      break;
    }
  } // endLoop
  //------------------
  debugger;
  if (j < 1 && attrs.noMatchRoute != null) {
    // 都沒解，那是否有設置沒解的方案
    let fn = attrs.noMatchRoute;
    fn();
  }
}
//--------------------------------------
function mergeObj(target, b) {
  for (let k in b) {
    if (k in target) {
      throw new Error(`(${k}) has defined`);
    }
    target[k] = b[k];
  }
}
//--------------------------------------
function getLocationData() {

  let data;

  if (!$locationKeys.length) {
    data = Object.assign({}, window.location);
    for (let k in data) {
      if (typeof (data[k]) == 'function') {
        delete (data[k]);
      }
      $locationKeys.push(k);
    }
  } else {
    data = {};
    $locationKeys.forEach((k) => {
      data[k] = window.location[k];
    });
  }

  if (data.hash.length) {
    data.hash = data.hash.slice(1);
  }
  if (data.search.length) {
    data.search = data.search.slice(1);
  }
  return data;
}
//--------------------------------------
function checkBaseUrl(urlData) {
  let res = {
    pathname: null,
    origin: null,
    hash: null,
    search: null,
  };

  if (typeof urlData == 'string') {
    let url;

    let str = urlData;

    while (true) {
      const regRes = $REG_1.exec(str);
      if (res == null) {
        url = str;
        break;
      }
      const {
        index,
        1: g1,
        2: g2
      } = regRes;

      let str_1 = str.slice(index + 1);

      if (g1 != null) {
        res.hash = str_1;
      } else {
        res.search = str_1
      }
      str = str.slice(0, index);
    };

    res.pathname = url.replace($REG_2, (m) => {
      res.origin = m;
      return '';
    });

  } else {
    for (let key in res) {
      if (urlData[key] != null) {
        res[key] = urlData[key];
      }
    }
  }
  return res;
}
//--------------------------------------
function getSyncJob($this) {
  const handle = setTimeout(function () {
    debugger;

    const attrs = $this.$$$attrs;
    attrs.syncJob = null;

    checkRouters.call($this, attrs.event);
    attrs.event = null;
  }, 0);

  return handle;
}
