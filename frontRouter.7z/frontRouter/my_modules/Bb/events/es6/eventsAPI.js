let $GM;

// global event
let $g_event;

const $attrName_1 = '$bb_event';

const $REG_1 = /[a-zA-Z]$/;
const $REG_2 = /^([a-z])([^]*)/i;
const $REG_3 = /^\[object Object\]$/;

const $plainObject = {};
const $eventClassCache = {};

//----------------------------

// 對外的 API
function Events(options, ...extendList) {
	// debugger;

	if (this instanceof Events) {
		throw new Error('Events cant be new');
	}

	options = options || {};

	const { cache = true } = options

	const Event = Events.getClass(options, cache);
	const event = new Event();

	for (let i = extendList.length; i > 0; i--) {

		const item = extendList[i - 1];

		for (let key in item) {
			if (key in event) {
				throw new Error(`(${key}) has exist`);
			}
			event[key] = item[key]
		}
	}

	return event;
}
//----------------------------------------------------------
// 把 event 的功能拷貝到目標
Events.mixin = function (target, options = {}) {
	debugger;

	let {
		simple = true,
		prefix = null
	} = options;
	const isSimpleMode = simple;

	const {
		CoreEvent,
		// proto_simple,
		// proto_complex,
		simple_copyList,
		complex_copyList
	} = $GM.get('event');

	prefix = checkPrefix(prefix);
	// options.prefix = null;
	//------------------

	if (target == null || typeof target != 'object') {
		throw new TypeError('...');
	}

	if ($attrName_1 in target) {
		throw new Error('has mixin before');
	}
	//------------------
	debugger;

	// 重要地方
	// 每個物件對映一個 CoreEvent
	const core = new CoreEvent();	

	if (!Object.hasOwnProperty($attrName_1)) {
		Object.defineProperty(target, $attrName_1, {
			configurable: true,
			value: core,
			writable: true,
			enumerable: false,
		});
	}
	//------------------

	let copyList = (isSimpleMode) ? simple_copyList : complex_copyList;
	copyList = Object.keys(copyList);

	// API 第一個字是否要轉大寫
	let isToUpperCase = null;
	if (prefix != null) {
		isToUpperCase = ($REG_1.test(prefix)) ? true : false;
	}

	copyList.forEach((k) => {
		if (typeof core[k] != 'function') {
			return;
		}

		let key = k;

		if (isToUpperCase != null) {
			if (isToUpperCase) {
				key = k.replace($REG_2, function (m, g1, g2) {
					return (g1.toUpperCase() + g2);
				});
			}
			key = prefix + key;
		}

		// 檢查 key 是否會 override
		if (key in target) {
			throw new Error(`(${key}) has exist`);
		}

		// 複製功能
		const fun = core[k];

		target[key] = function (...args) {
			debugger;
			core.context = this;
			fun.apply(core, args);
		}

	});
};
//----------------------------------------------------------
// 取得 Event 的建構式
Events.getClass = function (options = {}) {
	let { cache = true } = options;

	return getEventClass(options, cache);
}
//----------------------------------------------------------
// 取得最上層的原型 class
Events.getRootClass = function () {
	const {
		EventTop
	} = $GM.get('event');
	return EventTop;
}
//----------------------------------------------------------
// 把 event 的功能植入原型鍊裏
Events.extends = function (target, options = {}) {
	debugger;

	const {
		EventFactory,
		EventTop,
		eventTop,
		simple_copyList,
		complex_copyList,
		proto_simple,
		proto_complex,
	} = $GM.get('event');

	let returnValue = null;

	if (target == null || typeof (target) != 'object') {
		throw new TypeError('...');
	}

	if (($attrName_1 in target) || target instanceof EventTop) {
		throw new Error('has extends before');
	}

	// 介入原本的原型鏈
	insertPrototype(target, options);
};
//----------------------------------------------------------
// Events.global
Object.defineProperty(Events, 'global', {
	enumerable: true,
	get() {
		if ($g_event == null) {
			$g_event = Events();
		}
		return $g_event;
	},
	set() { }
});
////////////////////////////////////////////////////////////////////////////////


//-------------------------------------------

// copy proto.function
function copyAttrs(prefix, isSimpleMode, target, ...args) {
	// debugger;

	if (!Array.isArray(copyList)) {
		copyList = Object.keys(copyList);
	}

	const {
		simple_copyList,
		complex_copyList
	} = $GM.get('event');

	let copyList = (isSimpleMode) ? simple_copyList : complex_copyList;
	copyList = Object.keys(copyList);

	let isToUpperCase = null;
	if (prefix != null) {
		isToUpperCase = ($REG_1.test(prefix)) ? true : false;
	}

	while (true) {
		// debugger;
		if (!args.length) {
			break;
		}
		let copy = args.pop();

		copyList.forEach((k) => {
			if (typeof copy[k] != 'function') {
				return;
			}

			let key = k;
			if (isToUpperCase) {

				key = k.replace($REG_2, function (m, g1, g2) {
					return (g1.toUpperCase() + g2);
				});
				key = prefix + key;
			}
			target[key] = copy[k];
		});
	}
	return target;
}
//-------------------------------------------
function checkPrefix(prefix) {
	if (prefix != null) {
		prefix = ("" + prefix) || null;
	}
	return prefix;
}
//-------------------------------------------
// 把 Event 的功能插入既有的原型鍊裏
function insertPrototype(obj, options = {}) {
	debugger;

	let {
		prefix = null,
		simple = true,
	} = options;

	prefix = checkPrefix(prefix);

	const {
		EventFactory,
		EventTop,
		eventTop,
		simple_copyList,
		complex_copyList,
		proto_simple,
		proto_complex,
	} = $GM.get('event');

	let insert;

	let targetProto = getTopCanUseProto(obj);
	debugger;

	const Event = getEventClass(options, true);
	insert = new Event();

	Object.setPrototypeOf(targetProto, insert);
}

//-------------------------------------------
// 取得最上層可用的原型
function getTopCanUseProto(obj) {

	let targetProto = obj;

	const toString = Object.prototype.toString;
	const hasOwnProperty = Object.prototype.hasOwnProperty;

	while (true) {
		debugger;
		let class2String;
		let temp = obj;

		obj = Object.getPrototypeOf(obj);

		if (obj == null) {
			break;
		}

		class2String = toString.call(obj);

		if (!$REG_3.test(class2String)) {
			targetProto = obj;
			continue;
		} else {
			debugger;

			let res = hasOwnProperty.call(obj, 'constructor');
			// is plainObject
			if (res && obj.constructor === $plainObject.constructor) {
				break;
			}
			// Object.create(null)
			targetProto = obj;
		}
	}
	return targetProto;
}
//-------------------------------------------
function getEventClass(options = {}, useCache = true) {

	let {
		prefix = null,
		simple = true,
	} = options;

	prefix = checkPrefix(prefix);

	const {
		EventFactory,
		EventTop,
		eventTop,
		proto_simple,
		proto_complex,
	} = $GM.get('event');

	//-----------------------
	let $proto;
	let res;


	if (!useCache) {
		// 取得的 Event 是獨一無二
		// 避免重要的原型被污染

		let Event = EventFactory();
		if (prefix == null) {

			$proto = (simple) ? proto_simple : proto_complex;

			// 避免重要原型被污染
			$proto = Object.create($proto);

		} else {
			// 要設定 prefix 會比較麻煩
			// 要針對 prefix 另創 prototype

			// 空的 Event，沒有任何方法
			$proto = new EventTop();

			// 複製方法
			copyAttrs(prefix, simple, $proto, proto_complex);
		}
		Event.prototype = $proto;
		Event.prototype.constructor = Event;

		res = Event;

	} else {
		// 使用者不會污染原型鏈

		// 從 cache 裏找
		const key = getkey_1(options);

		if ($eventClassCache[key] == null) {
			// 若 cache 裏沒有

			let Event = EventFactory();

			if (prefix == null) {

				$proto = (simple) ? proto_simple : proto_complex;

			} else {

				// 空的 Event，沒有任何方法
				$proto = new EventTop();

				// 複製方法
				copyAttrs(prefix, simple, $proto, proto_complex);
			}

			Event.prototype = $proto;
			Event.prototype.constructor = Event;
			$eventClassCache[key] = Event;
		}

		res = $eventClassCache[key];

	}


	return res;
}
//-------------------------------------------
function getkey_1(options) {

	let {
		prefix = null,
		simple = true
	} = options;
	prefix = checkPrefix(prefix);

	let key = (prefix || '') + '|' + (simple ? 'simple' : 'complex');

	return key;
}

function factory(gm) {
	$GM = gm;
	return Events;
}

export default factory;
