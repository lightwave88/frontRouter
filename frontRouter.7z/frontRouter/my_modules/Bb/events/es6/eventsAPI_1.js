let $GM;

// global event
let $g_event;

const $attrName_1 = '$bb_event';

const $EventClassCache = {};
const $prefixPrototypeCache = {};
const $prototypeCache = {};

const $REG_1 = /[a-zA-Z]$/;
const $REG_2 = /^([a-z])([^]*)/i;
const $REG_3 = /^\[object Object\]$/;

const $plainObject = {};

//----------------------------

// 對外的 API
function Events(options, ...extendList) {
	debugger;

	if (this instanceof Events) {
		throw new Error('Events cant be new');
	}

	options = options || {};

	const Event = Events.getClass(options);
	const event = new Event();

	for (let i = extendList.length; i > 0; i--) {

		const item = extendList[i - 1];

		for (let key in item) {
			if (key in event) {
				throw new Error(`(${key}) has exist`);
			}
			event[key] = item[key]
		}
	}

	return event;
}
//----------------------------------------------------------
// 把 event 的功能拷貝到目標
Events.mixin = function (target, options = {}) {
	debugger;

	let {
		simple = true, prefix = null
	} = options;


	prefix = checkPrefix(prefix);
	options.prefix = null;
	//------------------
	let error = (() => {
		if (target == null) {
			return 'type error';
		}
		let type = typeof (target);
		switch (type) {
			case 'object':
			case 'function':
				break;
			default:
				return 'type error';
				break;
		}
	})();

	if (error != null) {
		throw new TypeError(error);
	}

	if (Object.hasOwnProperty(target, $attrName_1)) {
		throw new Error('has mixin before');
	}
	//------------------
	// debugger;

	const Event = Events.getClass(options);
	const core = new Event();

	const {
		simple_copyList,
		complex_copyList
	} = $GM.get('event');

	let copyList = (simple == true) ? simple_copyList : complex_copyList;
	copyList = Object.keys(copyList);

	// debugger;
	// console.dir(core);
	mixin(prefix, copyList, target, core);
};
//----------------------------------------------------------
// 取得 Event 的建構式
Events.getClass = function (options = {}) {
	debugger;

	let {
		prefix = null, simple = true
	} = options;
	prefix = checkPrefix(prefix);

	const {
		EventFactory,
		EventTop,
		eventTop,
		simple_copyList,
		complex_copyList,
		proto_simple,
		proto_complex,
	} = $GM.get('event');

	const index = getkeyFromOp(options);

	if (index in $EventClassCache) {
		return $EventClassCache[index];
	}
	//-----------------------
	const Event = EventFactory();

	if (prefix == null) {

		if (simple === false) {
			// 加入更多的 api
			Event.prototype = proto_complex;
		} else {
			Event.prototype = proto_simple;
		}

	} else {
		// 要設定 prefix 會比較麻煩
		// 要針對 prefix 另創 prototype
		let copyList = (simple == true) ? simple_copyList : complex_copyList;

		if (!(prefix in $prefixPrototypeCache)) {
			$prefixPrototypeCache[prefix] = {};
		}

		let map = $prefixPrototypeCache[prefix];

		let $proto;

		if (simple === false) {
			// 加入更多的 api

			// 查 cache
			if (!('complex' in map)) {
				let proto = map['complex'] = new EventTop();
				// 複製方法
				copyAttrs(prefix, copyList, proto, proto_complex);
			}
			$proto = map['complex'];

		} else {
			// 只需要簡易 API

			// 查 cache
			if (!('simple' in map)) {
				let proto = map['simple'] = new EventTop();
				// 複製方法
				copyAttrs(prefix, copyList, proto, proto_simple);
			}
			$proto = map['simple'];
		}
		Event.prototype = $proto;
	}

	Event.prototype.constructor = Event;

	$EventClassCache[index] = Event;

	return Event;
}
//----------------------------------------------------------
Events.getRootClass = function () {
	const {
		EventTop
	} = $GM.get('event');
	return EventTop;
}
//----------------------------------------------------------
// 把 event 的功能植入原型鍊裏
Events.extends = function (target, options = {}) {
	debugger;

	const {
		EventFactory,
		EventTop,
		eventTop,
		simple_copyList,
		complex_copyList,
		proto_simple,
		proto_complex,
	} = $GM.get('event');

	let returnValue = null;

	if (target == null || typeof (target) != 'object') {
		throw new TypeError('...');
	}

	if (($attrName_1 in target) || target instanceof EventTop) {
		throw new Error('has extends before');
	}

	// 介入原本的原型鏈
	insertPrototype(target, options);
};
//----------------------------------------------------------

// 可以不用
// getClass() 就可用到
Events.getPrototype = function (options = {}) {

	const index = getkeyFromOp(options);

	if (index in $prototypeCache) {
		return $prototypeCache[index];
	}

	const Event = Events.getClass(options);
	const event = new Event();

	$prototypeCache[index] = event;

	return event.prototype;
}
//----------------------------------------------------------
// Events.global
Object.defineProperty(Events, 'global', {
	enumerable: true,
	get() {
		if ($g_event == null) {
			$g_event = Events();
		}
		return $g_event;
	},
	set() { }
});
////////////////////////////////////////////////////////////////////////////////

// 把物件加入 Event API
function mixin(prefix, copyList, obj, core) {
	debugger;

	if (!Object.hasOwnProperty($attrName_1)) {
		Object.defineProperty(obj, $attrName_1, {
			configurable: true,
			value: core,
			writable: true,
			enumerable: false,
		});
	}
	//------------------
	let isToUpperCase = null;
	if (prefix != null) {
		isToUpperCase = ($REG_1.test(prefix)) ? true : false;
	}

	copyList.forEach((k) => {
		if (typeof core[k] != 'function') {
			return;
		}

		let key = k;

		if (isToUpperCase != null) {
			if (isToUpperCase) {
				key = k.replace($REG_2, function (m, g1, g2) {
					return (g1.toUpperCase() + g2);
				});
			}
			key = prefix + key;
		}

		// 檢查 key 是否會 override
		if (key in obj) {
			throw new Error(`(${key}) has exist`);
		}

		obj[key] = function (...args) {
			return core[k].apply(core, args);
		}
	});
}
//-------------------------------------------

// copy proto.function
function copyAttrs(prefix, copyList, target, ...args) {
	// debugger;

	if (!Array.isArray(copyList)) {
		copyList = Object.keys(copyList);
	}

	let isToUpperCase = null;
	if (prefix != null) {
		isToUpperCase = ($REG_1.test(prefix)) ? true : false;
	}

	while (true) {
		// debugger;
		if (!args.length) {
			break;
		}
		let copy = args.pop();

		copyList.forEach((k) => {
			if (typeof copy[k] != 'function') {
				return;
			}

			let key = k;
			if (isToUpperCase) {

				key = k.replace($REG_2, function (m, g1, g2) {
					return (g1.toUpperCase() + g2);
				});
				key = prefix + key;
			}
			target[key] = copy[k];
		});
	}
	return target;
}
//-------------------------------------------
function checkPrefix(prefix) {
	if (prefix != null) {
		prefix = ("" + prefix) || null;
	}
	return prefix;
}
//-------------------------------------------
function insertPrototype(obj, options = {}) {
	debugger;

	let {
		prefix = null, simple = true
	} = options;
	prefix = checkPrefix(prefix);

	const {
		EventFactory,
		EventTop,
		eventTop,
		simple_copyList,
		complex_copyList,
		proto_simple,
		proto_complex,
	} = $GM.get('event');

	const target = obj;
	const Event = EventFactory();
	let targetProto = obj;
	let insert;

	while (true) {
		debugger;
		let class2String;
		let temp = obj;

		obj = Object.getPrototypeOf(obj);

		if (obj == null) {
			break;
		}

		class2String = Object.prototype.toString.call(obj);

		if (!$REG_3.test(class2String)) {
			targetProto = obj;
			continue;
		} else {
			debugger;

			let res = Object.prototype.hasOwnProperty.call(obj, 'constructor');
			// is plainObject
			if (res && obj.constructor === $plainObject.constructor) {
				break;
			}
			// Object.create(null)
			targetProto = obj;
		}
	}
	//------------------
	// 插入者的 proto
	Event.prototype = new EventTop();
	Event.prototype.constructor = Event;

	//------------------
	// 複製 API
	let attrs;
	let copyTarget;

	if (simple) {
		attrs = Object.keys(simple_copyList);
	} else {
		attrs = Object.keys(complex_copyList);
	}

	copyAttrs(prefix, attrs, Event.prototype, proto_complex);
	//------------------
	debugger;

	insert = new Event();

	Object.setPrototypeOf(targetProto, insert);
}


//-------------------------------------------
function getkeyFromOp(options) {

	let {
		prefix = null, simple = true
	} = options;
	prefix = checkPrefix(prefix);

	let key = (prefix || '') + '|' + (simple ? 'simple' : 'complex');

	return key;
}
//-------------------------------------------
function factory(gm) {
	$GM = gm;
	return Events;
}

export default factory;
