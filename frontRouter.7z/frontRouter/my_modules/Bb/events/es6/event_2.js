const $REG_1 = /[.][^]*$/;
const $REG_2 = /[.]/;
const $REG_3 = /^all[.]/;
const $REG_4 = /^all$/;

let $GM;
let $UID = 0;

// 把 Event.prototype 獨立出來
const $proto_1 = Object.create(null);
const $proto_2 = Object.create(null);


function getModule() {
  // 確保每次的 Event 都不同

  // class Eventtt
  function Event(context = null) {

    // 主要參數，避免撞名
    const attrs = this.$$$event_attrs = {
      id: null,
      // 記錄被誰監聽
      listened: {},
      // 監聽者
      listeningTo: {},
      context: null,
      events: {
        // 本身事件
        self: {},
        // 跨物件事件
        cross: {},
      },
      // 檢查用，檢查某個 eventList 是否正在被引用
      locks: {},
    };

    attrs.id = `event_${++$UID}`;

    if (context != null) {
      attrs.context = context;
    }else{
      attrs.context = this;
    }
  }

  return {
    'Event': Event,
    'prototype_1': $proto_1,
    'prototype_2': $proto_2,
  };
}
////////////////////////////////////////////////////////////////////////////////
// Event.prototype_1
(function () {
  debugger;

  this.emit = function (eventName, ...args) {
    debugger;

    checkEventName(eventName);

    if ($REG_4.test(eventName)) {
      // eventName == 'all'
      return this.emitAll.apply(this, args);
    }
    //------------------
    const firstName = getFirstName(eventName);

    // 要檢查的列表
    let checks = ['self', 'cross'];

    let allList = [];
    //------------------
    const { events: $events } = this.$$$event_attrs;

    checks.forEach((name, i) => {
      debugger;

      const eventMap = $events[name];

      let data = {
        name,
        eventListName: null,
      };

      if (!$REG_4.test(firstName) && (firstName in eventMap)) {
        let data = {
          name,
          eventListName: firstName,
        };
        allList.push(data);
      }

      if ('all' in eventMap) {
        let data = {
          name,
          eventListName: 'all',
        };
        allList.push(data);
      }
    });
    //------------------
    debugger;

    let options = {
      firstName,
      eventName
    };

    allList.forEach((d) => {
      debugger;
      trigger.call(this, d, options, args);
    });
  };
  //----------------------------------------------------------------------------
  this.emitAll = function (...args) {
    debugger;

    const eventName = 'all';

    // 要檢查的列表
    let checks = ['self', 'cross'];
    //------------------
    const { events: $events } = this.$$$event_attrs;

    let list_1 = [];

    checks.forEach((name, i) => {
      debugger;

      const list = [];
      list_1.push(list);

      const eventMap = $events[name];

      for (let e in eventMap) {
        let data = {
          name,
          eventListName: null,
        };

        data.eventListName = e;

        if ($REG_4.test(e)) {
          // all 放在後面
          list.unshift(data);
        } else {
          list.push(data);
        }
      }

      // 確保 all 在最後
      if (list.length > 1 && $REG_4.test(list[0].eventListName)) {
        let data = list.shift();
        list.push(data);
      }
    });
    //------------------
    let allList = [];

    list_1.forEach((list) => {
      allList = allList.concat(list);
    });

    // debugger;
    let options = {
      firstName: eventName,
      eventName,
    };
    //------------------
    allList.forEach((d) => {
      debugger;
      trigger.call(this, d, options, args);
    });
  }
  //----------------------------------------------------------------------------
  this.on = function (eventName, listener) {
    debugger;

    if (typeof listener != 'function') {
      throw new Error('event.on no set listner');
    }

    checkEventName(eventName);
    //------------------
    let list = initEvents.call(this, 'self', eventName);

    const { EventHandle } = $GM.get('EventHandle_classes');

    let event = new EventHandle({
      context: (this.$context),
      callback: listener,
      eventName
    });

    list.push(event);
  }
  //----------------------------------------------------------------------------
  this.once = function (eventName, listener) {
    if (typeof listener != 'function') {
      throw new Error('event.on no set listner');
    }

    checkEventName(eventName);
    //------------------
    let list = initEvents.call(this, 'self', eventName);

    const { EventHandle } = $GM.get('EventHandle_classes');

    let event = new EventHandle({
      context: (this.$context),
      callback: listener,
      eventName,
      count: 1,
    });

    list.push(event);
  }
  //----------------------------------------------------------------------------
  this.hasListen = function (eventName, listener) {
    checkEventName(eventName);

    // 未
  }
  //----------------------------------------------------------------------------
  this.off = function (eventName, listener) {

    eventName = (eventName == null)?null:eventName;
    listener = listener || null;

    let firstName;

    if(eventName != null){
      checkEventName(eventName);
      firstName = getFirstName(eventName);
    }

    const listData = {
      name: 'self',
      eventListName: null,
    };

    let list = [];

    if(eventName != null){
      list.push(Object.assign(listData, {eventListName: firstName}));
    }else{
        const eventMap = this['$$$event_attrs'].events['self'];
    }

    const operate = {};

    list.forEach((listData, i) => {
      off.call(this, listData, operate);
    });
  }
  //----------------------------------------------------------------------------
  this.removeAllListeners = function (eventName, listener) {
    checkEventName(eventName);

    // 未
  }
  //----------------------------------------------------------------------------
  // 返回已注册监听器的事件名数组
  this.eventNames = function (eventName) {
    // 未
  }
  //----------------------------------------------------------------------------
  // 返回正在监听的名为 eventName 的事件的监听器的数量
  this.listenerCount = function (eventName) {
    // 未
  }
  //----------------------------------------------------------------------------
  // 返回名为 eventName 的事件的监听器数组的副本
  this.listeners = function (eventName) {
    // 未
  }
  //----------------------------------------------------------------------------


}).call($proto_1);
////////////////////////////////////////////////////////////////////////////////
// Event.prototype_2

(function () {

  this.listenTo = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  this.listenToOnce = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  this.hasListenTo = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  this.removeListenTo = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  this.removeAllListenTo = function (obj, eventName) {

  }
  //----------------------------------------------------------------------------
  // 不再被另一個物件聆聽
  this.stopBylistening = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  this.stopAllBylistening = function (obj, eventName) {

  }

}).call($proto_2);
////////////////////////////////////////////////////////////////////////////////

function getFirstName(eventName) {
  return eventName.replace($REG_1, '');
}
//-------------------------------------------
// 只負責執行適配的 listener
function trigger(listData = {}, operate = {}, args) {
  debugger;

  const {
    events: $events,
    context: $context,
    locks: $locks,
  } = this.$$$event_attrs;

  const {
    name,
    eventListName
  } = listData;

  const {
    // 事件的第一個名字
    firstName,
    // 完整的事件名稱
    eventName,
  } = operate;

  const events = $events[name][eventListName];

  const target = $context;
  //------------------
  // 上鎖
  /*
    最大的問題是在 emit(trigger)未結束前
    有可能動態的變動 eventList
    尤其以刪除影響最大

    1.emit 未結束卻清除 eventList
    2.emit 未結束又增加 listener
    3.emit 未結束但再次套嵌 emit
  */
  if ($locks[name] == null) {
    $locks[name] = {};
  }

  if ($locks[name][eventListName] == null) {
    $locks[name][eventListName] = 0;
  }
  ++$locks[name][eventListName];
  //------------------
  let data = null;

  switch (args.length) {
    case 0:
      break;
    case 1:
      data = args[0];
      break;
    default:
      data = args;
      break;
  }

  const callback_arg = {
    data,
    target,
    trigger: eventName,
  };
  //------------------
  const isEmitAll = ($REG_4.test(eventName)) ? true : false;

  debugger;
  events.forEach((handle, i) => {
    debugger;

    if (handle.del === true) {
      return;
    }

    if (!isEmitAll) {
      // checkNameSpace
      if (!checkNamespace.call(this, eventName, handle.eventName)) {
        return;
      }
    }

    if (typeof handle.count == 'number' && --handle.count <= 0) {
      // once
      handle.del = true;
    }
    //-------------
    let context = handle.context;

    let arg = Object.assign({
      eventName: handle.eventName
    }, callback_arg);

    if ('listener' in handle) {
      arg.listener = handle.listener;
    }

    // 執行 listener
    const callback = handle.callback;
    callback.call(context, arg);
  });
  //------------------
  // 解鎖
  if (--$locks[name][eventListName] == 0) {
    delete $locks[name][eventListName];

    // 只有一開始進來的 trigger 可以執行刪除
    clearHandle.call(this, events, name, eventListName);
  }

  if (!Object.keys($locks[name]).length) {
    delete $locks[name];
  }
}
//-------------------------------------------
function off(listData = {}, operate = {}) {
  debugger;

  const {
    events: $events,
    locks: $locks,
  } = this.$$$event_attrs;

  const {
    name,
    eventListName
  } = listData;

  const {
    // 完整的事件名稱
    eventName,
    removeAll = false,
    callback = null,
    listener = null,
  } = operate;

  if ($events[name] == null || $events[name][eventListName] == null) {
    // 沒有登錄
    return;
  }

  const isCheckNameSpace = (eventName == eventListName) ? false : true;

  const eventList = $events[name][eventListName];

  for (let i = 0, match = 0; eventList[i] != null; i++) {
    debugger;

    if(handle.del){
      // 被其他步驟標定爲將被 del
      continue;
    }

    let handle = eventList[i];

    if(isCheckNameSpace && !checkNamespace(eventName, handle.eventName)){
      continue;
    }

    if(callback != null && callback !== handle.callback){
        continue;
    }

    if(listener != null && handle.listener != null){
      const _listener = handle.listener;
      if(listener['$$$event_attrs'].id !== _listener['$$$event_attrs'].id){
        continue;
      }
    }

    // 標記爲刪除
    handle.del = true;

    if (!removeAll && ++match > 0) {
      break;
    }
  } // endLoop
  //------------------
  // 檢查鎖
  if (locks[name] != null && locks[name][eventListName] != null) {
    // eventList 正被操作中
    return;
  }
  //------------------
  clearHandle.call(this, eventList, name, eventListName);
}
//-------------------------------------------
// 確定 eventName 的正確性
function checkEventName(eventName) {
  if ($REG_3.test(eventName)) {
    throw new Error('event all cant use namespace');
  }
}
//-------------------------------------------
// click.a
function checkNamespace(eventName, handle_eventName) {
  // debugger;

  // eventName 不會是 'all'

  if ($REG_4.test(handle_eventName)) {
    // handle_eventName == 'all'
    // 所有事件都 match
    return true;
  }

  // 處理 '.'
  const reg_1 = RegExp($REG_2, 'g');

  // 處理 a.b.c 裏的 '.'
  // 要化爲 RegExp
  let reg_string = eventName.replace(reg_1, (m) => {
    return `[${m}]`;
  });
  const reg_2 = RegExp(`^${reg_string}`);

  let res = reg_2.test(handle_eventName);

  return res;
}
//-------------------------------------------

// 清除被標記要刪除的 handle
function clearHandle(events, name, eventListName) {
  debugger;
  for (let i = 0; events[i] != null; i++) {
    debugger;
    let handle = events[i];

    if (handle.del === true) {
      events.splice(i, 1);

      if(handle.listener != null){

      // 檢查連接關係
      checkBridge.call(this, handle, eventListName);
    }
      i--;
    }
  }
  debugger;
  const { events: $events } = this.$$$event_attrs;
  //------------------
  if (!events.length) {
    let eventMap = $events[name];
    delete (eventMap[eventListName]);
  }
}
//-------------------------------------------
function initEvents(name, eventName, listener = null, listeningTo = null) {
  const { events: $events } = this['$$$event_attrs'];

  const firstName = getFirstName(eventName);

  const eventMap = $events[name];

  if (!(firstName in eventMap)) {
    eventMap[firstName] = []
  }
  //------------------
  if (listener != null) {
    // 物件之間的連接

    // 被傾聽者
    let a_attrs = listeningTo['$$$event_attrs'];
    // 傾聽者
    let b_attrs = listener['$$$event_attrs'];

    // 確定是否有連接

    let a_map = a_attrs.listened;
    let b_map = b_attrs.listeningTo;

    if (a_map[b_attrs.id] == null) {
      // 若兩者之間沒有連接的資訊

      a_map[b_attrs.id] = {};
      b_map[a_attrs.id] = a_map[b_attrs.id];
    }

    let linkInfo = a_map[b_attrs.id];

    if (linkInfo[firstName] == null) {
      // 若連接資訊中，沒有對事件的記錄
      linkInfo[firstName] = 1;
    }
  }

  return eventMap[firstName];
}

//-------------------------------------------
// 檢查 handle 記錄的連接
function checkBridge(handle, eventListName) {
  debugger;

  const { listener, listeningTo } = handle;

  // 被傾聽者
  let a_attrs = listeningTo['$$$event_attrs'];

  // 傾聽者
  let b_attrs = listener['$$$event_attrs'];

  let a_map = a_attrs.listened;

  // 記錄兩者間的連接資訊
  let linkInfo = a_map[b_attrs.id];

  if (--linkInfo[eventListName] == 0) {
    delete linkInfo[eventListName];


    if (!Object.keys(linkInfo).length) {
      // 之間沒有任何連接資訊
      // 清除連接關係

      delete a_map[b_attrs.id];

      let b_map = b_attrs.listeningTo;
      delete b_map[a_attrs.id];
    }
  }
}
//-------------------------------------------
// 取得 event 本體
function getEventObj(obj) {
  let res = null;
  while (true) {
    if (obj['$$$event_attrs'] != null) {
      res = obj['$$$event_attrs'];
      break;
    }

    if (obj['$bb_event'] != null) {
      // mixin
      obj = obj['$bb_event'];
      continue;
    }
    break;
  }
  return res;
}
//------------------------------------------------------------------------------
function factory(gm) {
  $GM = gm;
  return getModule;
}

export default factory;
