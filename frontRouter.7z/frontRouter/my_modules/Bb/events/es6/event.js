const $REG_1 = /[.][^]*$/;
const $REG_2 = /[.]/;
const $REG_3 = /^all[.]/;
const $REG_4 = /^all$/;

let $GM;

const $attrName_1 = '$bb_event';

// 原型鏈的最頂端
class EventTop { };
const $eventTop = new EventTop();


// 把 Event.prototype 獨立出來
const $proto_simple = Object.create($eventTop);
const $proto_complex = Object.create($eventTop);

// API 複製列表
const $simple_copyList = {};
const $complex_copyList = {};


apiFactory_1.call($proto_simple);
apiFactory_1.call($proto_complex);
apiFactory_2.call($proto_complex);
apiFactory_1.call($simple_copyList);
apiFactory_1.call($complex_copyList);
apiFactory_2.call($complex_copyList);

////////////////////////////////////////////////////////////////////////////////
// Event.prototype_1
function apiFactory_1() {
  // debugger;

  this.emit = function (...args) {
    debugger;
    const core = this[$attrName_1];
    core.context = this;
    core.emit.apply(core, args);
  };
  //----------------------------------------------------------------------------
  this.emitAll = function (...args) {
    debugger;

    const core = this[$attrName_1];
    core.context = this;
    core.emitAll.apply(core, args);
  }
  //----------------------------------------------------------------------------
  this.on = function (...args) {
    debugger;
    const core = this[$attrName_1];
    core.context = this;
    core.on.apply(core, args);
  }
  //----------------------------------------------------------------------------
  this.once = function (...args) {
    debugger
    const core = this[$attrName_1];
    core.context = this;
    core.once.apply(core, args);
  }
  //----------------------------------------------------------------------------
  // 移除 listener
  this.off = function (eventName, listener) {
    debugger;

    const core = this[$attrName_1];
    core.context = this;
    core.off.call(core, eventName, listener);
  }

  //----------------------------------------------------------------------------
  this.hasListen = function (eventName, listener) {
    checkEventName(eventName);

    // 未
  }
  //----------------------------------------------------------------------------
  // 返回已注册监听器的事件名数组
  this.eventNames = function (eventName) {
    // 未
  }
  //----------------------------------------------------------------------------
  // 返回正在监听的名为 eventName 的事件的监听器的数量
  this.listenerCount = function (eventName) {
    // 未
  }
  //----------------------------------------------------------------------------
  // 返回名为 eventName 的事件的监听器数组的副本
  this.listeners = function (eventName) {
    // 未
  }
  //----------------------------------------------------------------------------


}
////////////////////////////////////////////////////////////////////////////////
// Event.prototype_2

function apiFactory_2() {

  this.listenTo = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  this.listenToOnce = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  this.hasListenTo = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  this.removeListenTo = function (obj, eventName, listener) {

  }
  //----------------------------------------------------------------------------
  // 找出有誰在傾聽他
  this.listening = function (obj, eventName, listener) {

  }

}
////////////////////////////////////////////////////////////////////////////////

let $UID = 0;

// Event 的核心
class CoreEvent {
  id;
  // 記錄被誰監聽
  listened = {};
  // 監聽者
  listeningTo = {};
  $context = null;
  events = {
    // 本身事件
    self: {},
    // 跨物件事件
    cross: {},
  };
  // 檢查用，檢查某個 eventList 是否正在被引用
  locks = {};
  //----------------------------------------------------------------------------
  // 確保能取得不一樣的 Event class
  // 因爲每個 Event.prototype 都不同
  static getClass() {
    // debugger;

    // class Event 的對外暴露
    // 可控制 API，避免外漏不必要的 API
    // CoreEvent 的包裹
    function Event() {

      if (!(this instanceof Event)) {
        throw new Error('must Event constructor must with new');
      }

      const core = new CoreEvent();

      if (!Object.hasOwnProperty($attrName_1)) {
        Object.defineProperty(this, $attrName_1, {
          configurable: true,
          value: core,
          writable: true,
          enumerable: false,
        });
      }
    }

    return Event;
  }

  //----------------------------------------------------------------------------
  constructor() {
    // debugger;
    this.id = `event_${++$UID}`;
  }
  get context(){
    return (this.$context == null)? this: this.$context;
  }

  set context(context){
    if(this.$context != null || context == this){
      return;
    }
    this.$context = context;
  }
  //----------------------------------------------------------------------------
  emit(eventName, ...args) {
    debugger;

    const context = this.context;

    this._checkEventName(eventName);

    if ($REG_4.test(eventName)) {
      // eventName == 'all'
      return this.emitAll(this, args);
    }
    //------------------
    const firstName = this._getFirstName(eventName);

    // 要檢查的列表
    let checks = ['self', 'cross'];

    let allList = [];
    //------------------

    checks.forEach((name, i) => {
      debugger;

      const eventMap = this.events[name];

      if (!$REG_4.test(firstName) && (firstName in eventMap)) {

        let data = {
          name,
          eventListName: null,
          eventListName: firstName,
        };

        allList.push(data);
      }

      if ('all' in eventMap) {

        let data = {
          name,
          eventListName: null,
          eventListName: 'all',
        };

        allList.push(data);
      }
    });
    //------------------
    debugger;

    let options = {
      firstName,
      eventName,
      context,
    };

    allList.forEach((d) => {
      debugger;
      this._trigger(d, options, args);
    });
  }
  //----------------------------------------------------------------------------
  emitAll(...args) {
    // debugger;

    const context = this.context;

    const eventName = 'all';

    // 要檢查的列表
    let checks = ['self', 'cross'];
    //------------------

    let list_1 = [];

    checks.forEach((name, i) => {
      debugger;

      const list = [];
      list_1.push(list);

      const eventMap = this.events[name];

      for (let e in eventMap) {
        let data = {
          name,
          eventListName: null,
        };

        data.eventListName = e;

        if ($REG_4.test(e)) {
          // all 放在後面
          list.unshift(data);
        } else {
          list.push(data);
        }
      }

      // 取保 all 在最後
      if (list.length > 1 && $REG_4.test(list[0].eventListName)) {
        let data = list.shift();
        list.push(data);
      }
    });
    //------------------
    let allList = [];

    list_1.forEach((list) => {
      allList = allList.concat(list);
    });

    // debugger;
    let options = {
      firstName: eventName,
      eventName,
      context,
    };
    //------------------
    allList.forEach((d) => {
      debugger;
      this._trigger(d, options, args);
    });
  }
  //----------------------------------------------------------------------------
  // 註冊 listener
  on(eventName, listener) {
    debugger;

    const context = this.context;

    if (typeof listener != 'function') {
      throw new Error('event.on no set listner');
    }

    this._checkEventName(eventName);
    //------------------
    let list = this._initEvents('self', eventName);

    const { EventHandle } = $GM.get('EventHandle_classes');

    let event = new EventHandle({
      context,
      callback: listener,
      eventName
    });

    list.push(event);
  }
  //----------------------------------------------------------------------------
  once(eventName, listener) {

    const context = this.context;

    if (typeof listener != 'function') {
      throw new Error('event.on no set listner');
    }

    this._checkEventName(eventName);
    //------------------
    let list = this._initEvents('self', eventName);

    const { EventHandle } = $GM.get('EventHandle_classes');

    let event = new EventHandle({
      context,
      callback: listener,
      eventName,
      count: 1,
    });

    list.push(event);
  }
  //----------------------------------------------------------------------------
  off(eventName, listener) {

    const context = this.context;

    if (eventName != null) {
      eventName = ("" + eventName) || null;
    }

    listener = listener || null;

    // 事件的第一個名字
    let firstName;
    let findList = [];
    const operate = {
      eventName,
      callback: listener,
      removeAll: false,
    };

    if (eventName != null) {
      this._checkEventName(eventName);
      firstName = this._getFirstName(eventName);
    }

    const listData = {
      name: 'self',
    };
    //------------------
    // 確定要檢查的 eventList
    if (eventName != null) {
      Object.assign(listData, { eventListName: firstName });
      findList.push(listData);
    } else {
      // 沒指定要刪除的事件
      // 那就要刪除所有事件
      const eventMap = this.events['self'];
      const keyList = Object.keys(eventMap);

      keyList.forEach((key) => {
        let _listData = Object.assign({}, listData, { eventListName: key });
        findList.push(_listData);
      });
    }
    //------------------

    findList.forEach((listData, i) => {
      debugger;
      this._off(listData, operate);
    });

  }
  //----------------------------------------------------------------------------
  // 觸發事件的核心
  _trigger(listData = {}, operate = {}, args) {
    debugger;

    const $events = this.events;
    const $locks = this.locks;

    const {
      name,
      eventListName
    } = listData;

    const {
      // 事件的第一個名字
      firstName,
      // 完整的事件名稱
      eventName,
      context: $context,
    } = operate;

    const events = $events[name][eventListName];

    const target = $context;
    //------------------
    // 上鎖
    /*
     最大的問題是在 emit(trigger)未結束前
     有可能動態的變動 eventList
     尤其以刪除影響最大

     1.emit 未結束卻清除 eventList
     2.emit 未結束又增加 listener
     3.emit 未結束但再次套嵌 emit
     */
    if ($locks[name] == null) {
      $locks[name] = {};
    }

    if ($locks[name][eventListName] == null) {
      $locks[name][eventListName] = 0;
    }
    ++$locks[name][eventListName];
    //------------------
    let data = null;

    switch (args.length) {
      case 0:
        break;
      case 1:
        data = args[0];
        break;
      default:
        data = args;
        break;
    }

    const callback_arg = {
      data,
      target,
      trigger: eventName,
    };
    //------------------
    const isEmitAll = ($REG_4.test(eventName)) ? true : false;

    debugger;
    events.forEach((handle, i) => {
      debugger;

      if (handle.del === true) {
        return;
      }

      if (!isEmitAll) {
        // checkNameSpace
        if (!this._checkNamespace(eventName, handle.eventName)) {
          return;
        }
      }

      if (typeof handle.count == 'number' && --handle.count <= 0) {
        // once
        handle.del = true;
      }
      //-------------
      let context = handle.context;

      let arg = Object.assign({
        eventName: handle.eventName
      }, callback_arg);

      if ('listener' in handle) {
        arg.listener = handle.listener;
      }

      // 執行 listener
      const callback = handle.callback;
      debugger;
      callback.call(context, arg);
    });
    //------------------
    // 解鎖
    if (--$locks[name][eventListName] == 0) {
      delete $locks[name][eventListName];

      // 只有一開始進來的 trigger 可以執行刪除
      this._clearHandle(name, eventListName);
    }

    if (!Object.keys($locks[name]).length) {
      delete $locks[name];
    }
  }
  //----------------------------------------------------------------------------
  _off(listData = {}, operate = {}) {
    debugger;

    const $events = this.events;
    const $locks = this.locks;

    const {
      name,
      eventListName
    } = listData;

    const {
      // 完整的事件名稱
      eventName = null,
      removeAll = false,
      callback = null,
      // 傾聽者
      listener = null,
    } = operate;

    if ($events[name] == null || $events[name][eventListName] == null) {
      // 要檢查的 eventList
      return;
    }
    const eventList = $events[name][eventListName];

    // 是否要檢查 event 的 namespace
    const isCheckNameSpace = (() => {
      if (eventName == null) {
        return false;
      }
      if (eventName === eventListName) {
        return false;
      }
      return true;
    });

    for (let i = 0, match = 0; eventList[i] != null; i++) {
      debugger;

      if (handle.del) {
        // 被其他步驟標定爲將被 del
        // 不需處理了
        continue;
      }

      const handle = eventList[i];

      //--------------
      // 確定是否是合乎刪除的條件
      if (isCheckNameSpace && !this._checkNamespace(eventName, handle.eventName)) {
        continue;
      }

      if (callback !== handle.callback) {
        continue;
      }

      // 若有指定要刪除的 listener
      if (listener != null && handle.listener != null) {
        const _listener = handle.listener;
        if (listener.id !== _listener.id) {
          continue;
        }
      }
      //--------------
      // 標記爲刪除
      handle.del = true;

      if (!removeAll && ++match > 0) {
        break;
      }
    } // endLoop


    // 檢查鎖
    if (locks[name] != null && locks[name][eventListName] != null) {
      // eventList 正被操作中
      return;
    }
    //------------------
    this._clearHandle(name, eventListName);
  }
  //----------------------------------------------------------------------------
  _initEvents(name, eventName, listener = null, listeningTo = null) {
    debugger;

    const $events = this.events;
    const eventMap = $events[name];

    const firstName = this._getFirstName(eventName);

    if (!(firstName in eventMap)) {
      eventMap[firstName] = [];
    }
    //------------------
    if (listener != null) {
      // 物件之間的連接

      // 被傾聽者
      const _listened = listeningTo.listened;
      // 傾聽者
      const _listeningTo = listener.listeningTo;

      // 確定是否有連接
      if (_listened[listener.id] == null) {
        // 若兩者之間沒有連接的資訊
        // 建立

        _listened[listener.id] = {};
        _listeningTo[listeningTo.id] = _listened[listener.id];
      }

      let linkInfo = _listened[listener.id];

      if (linkInfo[firstName] == null) {
        // 若連接資訊中，沒有對事件的記錄
        linkInfo[firstName] = 1;
      }
    }

    return eventMap[firstName];
  }
  //----------------------------------------------------------------------------
  // 確定 eventName 的正確性
  _checkEventName(eventName) {
    if ($REG_3.test(eventName)) {
      throw new Error('event all cant use namespace');
    }
  }
  //----------------------------------------------------------------------------
  // 取得事件的第一個名字
  _getFirstName(eventName) {
    return eventName.replace($REG_1, '');
  }
  //----------------------------------------------------------------------------
  // click.a
  _checkNamespace(eventName, handle_eventName) {
    // debugger;

    // eventName 不會是 'all'

    if ($REG_4.test(handle_eventName)) {
      // handle_eventName == 'all'
      // 所有事件都 match
      return true;
    }

    // 處理 '.'
    const reg_1 = RegExp($REG_2, 'g');

    // 處理 a.b.c 裏的 '.'
    // 要化爲 RegExp
    let reg_string = eventName.replace(reg_1, (m) => {
      return `[${m}]`;
    });
    const reg_2 = RegExp(`^${reg_string}`);

    let res = reg_2.test(handle_eventName);

    return res;
  }
  //----------------------------------------------------------------------------
  // 清除被標記要刪除的 handle
  _clearHandle(name, eventListName) {
    debugger;
    const eventMap = this.events[name];

    const events = eventMap[eventListName] || [];

    for (let i = 0; events[i] != null; i++) {
      debugger;
      let handle = events[i];

      if (handle.del === true) {
        events.splice(i, 1);

        if (handle.listener != null) {
          // 比較麻煩的地方
          // 有兩物件的連接關係
          // 檢查連接關係
          this._checkBridge(handle, eventListName);
        }
        i--;
      }
    }
    debugger;
    //------------------
    if (events.length == 0) {
      delete (eventMap[eventListName]);
    }
  }
  //----------------------------------------------------------------------------
  // 檢查 handle 記錄的連接
  _checkBridge(handle, eventListName) {
    debugger;

    const { listener, listeningTo } = handle;
    //------------------
    // 被傾聽者
    let _listened = listeningTo.listened;

    // 傾聽者
    let _listeningTo = listener.listeningTo;
    //------------------
    // 記錄兩者間的連接資訊
    let linkInfo = _listened[listener.id];

    if (linkInfo[eventListName] != null &&
      --linkInfo[eventListName] == 0) {
      delete linkInfo[eventListName];


      if (Object.keys(linkInfo).length == 0) {
        // 之間沒有任何連接資訊
        // 清除連接關係

        delete _listened[listener.id];
        delete _listeningTo[listeningTo.id];
      }
    }
  }
  //----------------------------------------------------------------------------
  // 取得 event 本體
  _getEventObj(obj) {
    debugger;
    let res = null;

    while (true) {
      debugger;
      if (obj instanceof CoreEvent) {
        // find
        res = obj;
        break
      }

      if (obj[$attrName_1] != null) {
        // mixin
        obj = obj[$attrName_1];
        continue;
      }
      break;
    }
    return res;
  }
  //----------------------------------------------------------------------------

}
//------------------------------------------------------------------------------
function factory(gm) {
  $GM = gm;
  return {
    EventTop: EventTop,
    eventTop: $eventTop,
    CoreEvent,
    'proto_simple': $proto_simple,
    'proto_complex': $proto_complex,
    'simple_copyList': $simple_copyList,
    'complex_copyList': $complex_copyList,
    EventFactory() {
      return CoreEvent.getClass();
    },

  };
}

export default factory;
