(function () {

    this.listenTo = function (obj, eventName, listener) {

    }
    //----------------------------------------------------------------------------
    this.listenToOnce = function (obj, eventName, listener) {

    }
    //----------------------------------------------------------------------------
    this.hasListenTo = function (obj, eventName, listener) {

    }
    //----------------------------------------------------------------------------
    this.removeListenTo = function (obj, eventName, listener) {

    }
    //----------------------------------------------------------------------------
    this.removeAllListenTo = function (obj, eventName) {

    }
    //----------------------------------------------------------------------------
    // 不再被另一個物件聆聽
    this.stopBylistening = function (obj, eventName, listener) {

    }
    //----------------------------------------------------------------------------
    this.stopAllBylistening = function (obj, eventName) {

    }

  }).call($proto_2);


