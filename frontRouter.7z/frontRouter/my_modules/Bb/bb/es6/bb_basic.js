'use strict';

// 工具集
const $BB = function () { };

export default $BB;
export { $BB };
//------------------------------------------------
// 可操作的全域變數
const $globalVar = new Map();
const $attrs = {};

const BBFuntions = {
  // 本身模組的擴增
  mixin(m) {
    // debugger;
    for (let key in m) {
      if (key in $BB) {
        throw new Error('has same attr');
      }
      $BB[key] = m[key];
    }
  },
  //---------------------------------
  // 可操作的全域變數
  get globalVar() {
    return $globalVar;
  },
  set globalVar(v) { },
  //---------------------------------
  //  attrs
  get attrs() {
    return $attrs;
  },
  set attrs(v) { }
}


Object.assign($BB, BBFuntions);
