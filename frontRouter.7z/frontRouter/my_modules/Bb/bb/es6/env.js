
let $BB;

// 環境資訊
const $ENV = {
  // global
  root: null,
  env: null,
  isWorker: null,
  baseUrl: null,
};
////////////////////////////////////////////////////////////////////////////////

const { WebEnv, NodeJsEnv } = (() => {
  //
  class interface_Env {
    $Bb;
    constructor() {
    }
    //--------------------------------------
    // 共同的操作
    sameProcess() {
      this.is_workerEnv();
    }
    //--------------------------------------
    // 是否是 worker 的運行環境
    is_workerEnv() {
      if (typeof (WorkerGlobalScope) != 'undefined') {
        $ENV.isWorker = true;
      } else {
        $ENV.isWorker = false;
      }
    }
  }
  //------------------------------------------------------------------------------
  class WebEnv extends interface_Env {
    constructor() {
      super();
      let root = (typeof self == 'object' && self.self === self) ? self : null;
      $ENV.root = root;

      this.sameProcess();

      this.setGlobalVariable();
    }
    //----------------------------
    setGlobalVariable() {
      window['$bb'] = $BB;
    }

  }
  //------------------------------------------------------------------------------
  class NodeJsEnv extends interface_Env {
    constructor() {
      super($BB);
      let root = (typeof global == 'object' && global.global === global) ? global : null;
      $ENV.root = root;

      this.sameProcess();
    }
  }


  return { WebEnv, NodeJsEnv };
})();
////////////////////////////////////////////////////////////////////////////////
function is_nodeJsEnv() {
  let res = false;
  try {
    let checkList = [process, require('fs')];
    res = checkList.every((obj) => {
      return (obj != null && typeof obj == 'object');
    });
  } catch (error) { }
  return res;
}
//---------------------------------
function is_browserEnv() {
  if (typeof window != 'undefined' && typeof document != 'undefined') {
    return true;
  }
  return false;
}
//---------------------------------
const f_env = function (Bb) {
  // debugger;

  $BB = Bb;

  if (is_nodeJsEnv()) {
    $ENV.env = 'nodejs';
    new NodeJsEnv();
  } else if (is_browserEnv()) {
    $ENV.env = 'browser';
    new WebEnv();
  } else {
    $ENV.env = 'unknow';
  }

  return $ENV;
};

export { f_env };
