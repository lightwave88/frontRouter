
import { $BB } from './bb_basic.js';

import { f_env } from './env.js';
$BB.attrs.ENV = f_env($BB);

export default $BB;
