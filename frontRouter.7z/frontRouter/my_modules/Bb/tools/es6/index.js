let $BB;
//------------------------------------------------------------------------------
const guid = (() => {
	// guid()
	// 取得獨一無二的 id
	const $guid = {
		namespace: {},
		uid: 0,
		getUid(namespace = null) {
			if (typeof namespace == 'string') {
				namespace = namespace.trim();
				namespace = (namespace.length) ? namespace : null;
			}

			if (namespace == null) {
				return this.uid++;
			}
			if (!(namespace in this.namespace)) {
				this.namespace[namespace] = 0;
			}
			return this.namespace[namespace]++;
		}
	};

	return function (namespace) {
		$guid.getUid(namespace);
	}
})();
//------------------------------------------------------------------------------
const isPlainObject = (() => {
	// from jquery
	const reg_1 = /^\[object Object\]$/;

	const proto_tooString = Object.prototype.toString;
	const class2type = {};
	const class2typeCts = {}.constructor;
	const hasOwn = class2type.hasOwnProperty;

	return function (obj) {
		// debugger;
		let proto, Ctor, res;

		if (typeof obj != 'object') {
			return false;
		}

		// Detect obvious negatives
		// Use toString instead of jQuery.type to catch host objects
		res = proto_tooString.call(obj);
		res = reg_1.test(res);

		if (!obj || !res) {
			return false;
		}

		proto = Object.getPrototypeOf(obj);

		// Objects with no prototype (e.g., `Object.create( null )`) are plain
		if (!proto) {
			return true;
		}

		// Objects with prototype are plain iff they were constructed by a global Object function
		Ctor = hasOwn.call(proto, "constructor") && proto.constructor;

		return (typeof Ctor == "function" && Ctor === class2typeCts);
	}
})();

//------------------------------------------------------------------------------
const getClass = (() => {
	// getClass
	function getClass(data) {
		let _toString = Object.prototype.toString;

		let type = typeof (data);

		if (/object/.test(type)) {

			if (data === null) {
				type = "null";
			} else {
				type = _toString.call(data);

				let res = /\[\w+\s+(\w+)\]/.exec(type);
				if (res && res[1]) {
					type = res[1];
				}
			}
		}
		return type;
	}

	return getClass;
})();
//------------------------------------------------------------------------------
const timeout = (() => {
	// job: [function|promise]
	function timeout(timeLimit, job, context) {
		let p1;

		if (typeof timeLimit != 'number') {
			throw new TypeError("timeout arg[1] must be number");
		}

		if (typeof (job) == "function") {

			if (context != null) {
				job = job.bind(context);
			}
			p1 = new Promise(job);
		} else if (job instanceof Promise) {
			p1 = job;
		} else {
			throw new TypeError("timeout arg[0] must be promise or function");
		}
		//-----------------------
		let _res;
		let _rej;

		let r_p = new Promise(function (res, rej) {

			_res = res;
			_rej = rej;
		});
		//-----------------------
		// 計時器
		let timeHandle = setTimeout(() => {
			_rej(new Error('timeout'));
		}, timeLimit);


		p1.then((data) => {

			clearTimeout(timeHandle);
			timeHandle = null;
			_res(data);
		}, (err) => {
			clearTimeout(timeHandle);
			timeHandle = null;
			_rej(err);
		});
		//-----------------------
		return r_p;
	}

	return timeout;
})();
//------------------------------------------------------------------------------
const { promise, deferred } = (() => {
	class Pr extends Promise {
		constructor(executor) {
			// debugger;

			// console.log(executor.toString());

			super((resolve, reject) => {
				return executor(resolve, reject);
			});
		}

		always(callback) {
			// debugger;
			let p = this.then((d) => {
				// debugger;
				return callback(null, d);
			}, (er) => {
				// debugger;
				return callback(er);
			});
			// 反囘原有的 promise

			// p = Promise.resolve(p);
			// debugger;
			return p;
		}
	}
	//--------------------------------------
	// promise
	//
	// callback: [function(返回 promise)|promise[]]
	// context: 背後執行對象
	function $promise(callback, context) {
		let p;

		if (callback instanceof Promise) {
			p = Pr.resolve(callback);
		} else if (typeof (callback) == "function") {

			callback = _bind(callback);

			p = new Pr(callback);
		} else if (Array.isArray(callback)) {

			let prList = callback.map(function (fn) {
				fn = _bind(fn, context);
				return new Pr(fn);
			});

			p = Pr.all(prList);
		}
		//-----------------------
		return p;
	}

	$promise.resolve = function (d) {
		return Pr.resolve(d);
	};

	$promise.reject = function (er) {
		return Pr.reject(er);
	};

	function _bind(fn, context) {
		if (context == null) {
			return fn;
		}
		return fn.bind(context);
	}
	//--------------------------------------
	class Def {
		$handle;
		$pr;
		constructor(timeout = null) {

			this.$pr = new Pr(($res, $rej) => {
				this.$handle = (function* () {
					let {
						error,
						data
					} = yield;

					if (error == null) {
						$res(data);
					} else {
						$rej(error);
					}
				})();
				this.$handle.next();
			});
			//------------------
			// 計時器
			if(typeof timeout == 'number'){
				setTimeout(() => {
					this.$handle.next({
						error: er,
						data: null
					});
				}, timeout);
			}
		}
		//------------------------------------------------
		get promise() {
			return this.$pr;
		}
		//------------------------------------------------
		set promise(v) {
			// throw new Error('cant set promise');
		}
		//------------------------------------------------
		resolve(data) {
			this.$handle.next({
				error: null,
				data
			});
		}
		//------------------------------------------------
		reject(er) {
			this.$handle.next({
				error: er,
				data: null
			});
		}
		//------------------------------------------------
	}
	function makeDeferred(timeout) {
		return new Def(timeout);
	}
	//--------------------------------------
	return {
		promise: $promise,
		deferred: makeDeferred
	};
})();
//------------------------------------------------------------------------------
// 對要形成 RegExp 的 str 做脫逸
const string2RegExpEscape = (() => {
	const $REG_1 = /\/|\\|\^|\$|\(|\)|\[|\]|\{|\}|\.|\*|\+|\?|\|/;
	return function (str) {
		const reg_1 = RegExp($REG_1, 'a');
		str = str.replace(reg, (m) => {
			return '\\' + m;
		});
		return str;
	};
})();
//------------------------------------------------------------------------------
// 注入
function f_tools(Bb) {
	$BB = Bb;

	$BB.mixin({
		guid,
		isPlainObject,
		getClass,
		timeout,
		promise,
		deferred,
		string2RegExpEscape,
	});
}

export { f_tools };
