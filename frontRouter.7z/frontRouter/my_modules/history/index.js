debugger;

import $GM from './es6/index.js';
//------------------

import historyModule from './es6/index.js';
const {bbHistory, bbHistoryExtend: hisExtend} = historyModule($GM);

export { bbHistory };
export var bbHistoryExtend = function(bb = null) {
	if (bb == null) {
		throw new Error('need im[ort $bb');
	}
	$GM.import('bb', bb);
	Object.assign(bb, hisExtend);
}
