'use strict';

let $GM;

const $sys = {
  '$history': null,
};

// history 功能
class HistoryAPI {

  $$$core;
  //--------------------------------------
  constructor() {
    // debugger;
    this.$$$core = new HistoryCore();
  }
  //--------------------------------------
  // 取得 his 相關的訊息
  get info() {
    return this.$$$core.$info;
  }

  set info(value) { }
  //--------------------------------------
  // state(存在 history 的資料)
  get data() {
    // debugger;
    return this.$$$core.$db;
  }

  set data(value) { }
  //--------------------------------------
  onPopstate(...args) {
    const core = this.$$$core;
    return core.onPopstate.apply(core, args);
  }
  //--------------------------------------
  // 改變 url
  pushState(...args) {
    const core = this.$$$core;
    return core.pushState.apply(core, args);
  }

}

////////////////////////////////////////////////////////////////////////////////
// 重建 window.history, window.location


let $UID_1 = 0;

class HistoryCore {

  $id;

  // stateData
  // 可以放比較多資料
  $db;

  // time => 1
  $historyData = new Map();
  $h_length;
  $syncJob;

  // 一些對外訊息
  $info;

  // 事件模組
  $event;

  // 登錄的事件
  $events = [];

  $current_stateID = null;
  $prev_stateID = null;

  $event_onPopstate;
  $event_onPushstate;

  // 用來確定 event 是由自己發的

  //--------------------------------------
  constructor() {
    debugger;

    this.$id = `history_${$UID_1++}`;

    // 儲存 state 的資料庫
    const HistoryDB = $GM.get('HistoryDB');
    this.$db = new HistoryDB(this);

    this._sysInit();

    //------------------
    const isNewPage = (() => {
      debugger;
      if (history.state == null || typeof (history.state) != 'object') {
        return true;
      }
      if (history.state.$$$id == null) {
        return true;
      }
      return false;
    })();
    //------------------
    this._isStateDataExist();

    this._synchistoryData();

    let eData = getEventObj(this, {
      isInit: true,
      isNewPage,
      direction: 1,
      currentID: (this.$current_stateID),
      prevID: (this.$prev_stateID),
    });

    this.$info = Object.assign({}, eData);

    this._bindEvent(isNewPage);
  }
  //--------------------------------------
  get data() {
    return this.$db;
  }
  set data(value) { }
  //--------------------------------------
  // API
  // 註冊 popstate 事件
  onPopstate(callback, once = false) {
    debugger;

    if (once) {
      callback = {
        callback,
        count: 1
      };
    }
    this.$events.push(callback);
  }
  //--------------------------------------
  // API
  // 改變 URL
  pushState(url) {
    // ++this.$emitCount;
    $sys.$history.pushState(null, null, url);
  }
  //--------------------------------------
  // listen onPopstate event
  _getOnPopstateEvent() {
    return (e) => {
      debugger;

      console.dir(history);

      // 重點
      let eData = this._eventCheck(e);

      this.$info = Object.assign({}, eData);

      this._callListener(eData);
    };
  }
  //--------------------------------------
  // bbHistory 剛建構
  _getOnInitEvent() {
    return (e) => {
      debugger;

      console.dir(history);

      // 沒有這步
      // this._eventCheck(e);

      this._callListener(this.$info);
    };
  }
  //--------------------------------------
  // 重點
  // 重點
  // 重點
  _eventCheck(e) {
    debugger;

    let data = {
      isNewPage: false,
      direction: 0,
      currentID: null,
      prevID: null,
    };

    this._isStateDataExist();

    const id = history.state.$$$id;

    if (!this.$historyData.has(id)) {

      // 全新的前進
      // 不是 history 的操作
      this._synchistoryData();

      // 同步 $historyData
      let delList = this._synchistoryData_1(this.$prev_stateID, this.$current_stateID);

      // 同步資料庫
      this._syncDB(delList);

      data.isNewPage = true;
    } else {
      // history 的操作 [back|forword]

      this._synchistoryData();
    }

    data.currentID = this.$current_stateID;
    data.prevID = this.$prev_stateID;

    let subtract = data.currentID - data.prevID;

    if (subtract > 0) {
      data.direction = 1;
    } else if (subtract < 0) {
      data.direction = -1;
    }

    data = getEventObj(this, data);

    return data;
  }
  //--------------------------------------
  _sysInit() {
    // debugger;

    if ($sys.$history == null) {
      $sys.$history = initHistory();
    }
  }
  //--------------------------------------
  _isStateDataExist() {
    // debugger;

    if (history.state != null &&
      typeof (history.state) == 'object' && history.state.$$$id != null) {
      return;
    }

    console.log('history.state 不存在，建立');

    let id = this._getId();
    history.replaceState({
      '$$$id': id,
      '$$$hisID': this.$id,
    }, null);
    return;
  }
  //--------------------------------------
  // 同步(history.state | stateData) 資料
  //
  // 因應 reload，history.state 有資料
  _synchistoryData() {
    debugger;

    const id = history.state.$$$id;

    this.$prev_stateID = (this.$current_stateID == null ?
      null : this.$current_stateID);

    this.$current_stateID = id;

    if (!this.$historyData.has(id)) {
      // 同步資料
      this.$historyData.set(id, 1);
    }
  }
  //--------------------------------------
  // 去掉沒用的歷史記錄
  _synchistoryData_1(old_id, new_id) {
    debugger;

    const hData = this.$historyData;

    if (!hData.has(new_id)) {
      hData.set(new_id);
    }

    let delList = [];

    hData.forEach((v, id) => {
      debugger;

      // 重要的演算法
      if (id > old_id && id < new_id) {
        delList.push(id);
        hData.delete(id);
      }
    });
    return delList;
  }
  //--------------------------------------
  _getId() {
    return (new Date()).getTime();
  }
  //--------------------------------------
  //
  _callListener(eData) {
    debugger;

    for (let i = 0; i < this.$events.length; i++) {
      // debugger;
      const callback = this.$events[i];

      if (typeof callback != 'function') {
        callback = callback.callback;

        this.$events.splice(i, 1);
        --i;
      }
      let e = Object.assign({}, eData);
      callback(e);

    } // loopEnd

  }
  //--------------------------------------
  _bindEvent() {
    // debugger;
    this.$event_onPopstate = this._getOnPopstateEvent();
    const $event_init = this._getOnInitEvent();

    window.addEventListener('bbHistoryInit', $event_init);
    window.addEventListener('popstate', this.$event_onPopstate);

    setTimeout(() => {
      debugger;
      // 使用異步是爲了給使用者
      // 註冊監聽的空檔

      let event = new Event('bbHistoryInit');
      window.dispatchEvent(event);
      window.removeEventListener('bbHistoryInit', $event_init);
    }, 0);
  }
  //--------------------------------------
  // 資料庫與歷史資料同步
  _syncDB(delList = []) {
    debugger;

    const db = this.$db;

    delList.forEach((id) => {
      debugger;
      if (db.hasByTime(id)) {
        db.deleteByTime(id);
      }
    });

  }
}
////////////////////////////////////////////////////////////////////////////////


function initHistory() {
  const history_proto = Object.getPrototypeOf(history);

  // 繼承 history
  const $history = Object.create(history);
  const pushState_fn = history_proto.pushState;

  // 覆寫方法
  $history.pushState = function (...args) {

    let res = pushState_fn.apply(history, args);
    let event = new Event('popstate');
    window.dispatchEvent(event);

    return res;
  }
  return $history;
}
//-------------------------------------------
// 統一 event.attrs
function getEventObj(his, merge = {}) {

  const state = history.state;
  let { $$$hisID, $$$id } = state;
  $$$hisID = parseInt($$$hisID, 10);

  let isSameHis = ($$$hisID == his.$id);

  let eData = {
    isSameHis,
    isInit: false,
    isNewPage: false,
    direction: null,
    currentID: null,
    prevID: null,
  };

  return Object.assign({}, eData, merge);
}
//------------------------------------------------------------------------------
export default function (gm) {
  debugger;

  $GM = gm;

  const bbHistory = new HistoryAPI();

  // history wrap
  const bbHistoryExtend = {
    get history() {
      debugger;
      return bbHistory;
    },
    set history(v) { }
  };

  // 匯出
  const $export = {
    bbHistory,
    bbHistoryExtend
  };

  return $export;
};
