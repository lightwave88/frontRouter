'use strict';

let $GM;
let $uniqueInstance;

const $sys = {
  '$history': null,
};

// history 功能
class HistoryAPI {

  $$$core;
  //--------------------------------------
  static getInstance() {
    if ($uniqueInstance == null) {
      $uniqueInstance = new HistoryAPI();
    }
    return $uniqueInstance;
  }

  //--------------------------------------
  constructor() {
    debugger;
    this.$$$core = new HistoryCore();
  }
  //--------------------------------------
  get history() {
    return $sys.$history;
  }

  set history(value) { }
  //--------------------------------------
  get id() {
    return this.$$$core.$id;
  }

  set id(v) { }
  //--------------------------------------
  onPopstate(...args) {
    const core = this.$$$core;
    return core.onPopstate.apply(core, args);
  }
  //--------------------------------------
  onPushstate(...args) {
    const core = this.$$$core;
    return core.onPushstate.apply(core, args);
  }
  //--------------------------------------
  setStateData(...args) {
    const core = this.$$$core;
    return core.setStateData.apply(core);
  }
  //--------------------------------------
  getStateData(...args) {
    const core = this.$$$core;
    return core.getStateData.apply(core, args);
  }
  //--------------------------------------
  getPrevStateData(...args) {
    const core = this.$$$core;
    return core.getPrevStateData.apply(core, args);
  }
  //--------------------------------------
  // 改變 url
  pushState(...args) {
    const core = this.$$$core;
    return core.pushState.apply(core, args);
  }

}

export default function (gm) {
  $GM = gm;

  const bbHistory = HistoryAPI.getInstance();

  // history wrap
  const $historyExtend = {
    get history() {
      debugger;
      return bbHistory;
    },
    set history(v) { }
  };

  // 匯出
  const $export = {
    bbHistory,
    historyExtend(bb) {
      Object.assign(bb, $historyExtend);
    }
  };

  return $export;
};

////////////////////////////////////////////////////////////////////////////////
// 重建 window.history, window.location


let $UID_1 = 0;

class HistoryCore {

  $id;

  $stateData = {};
  $h_length;
  $syncJob;

  // 事件模組
  $event;

  // 登錄的事件
  $events = {
    popstate: [],
    pushstate: [],
  };

  $current_stateID = null;
  $prev_stateID = null;

  $event_onPopstate;
  $event_onPushstate;

  // 用來確定 event 是由自己發的

  //--------------------------------------
  constructor() {
    debugger;

    this.$id = `history_${$UID_1++}`;

    this._sysInit();

    //------------------
    const isNewPage = (()=>{
      if(history.state == null || typeof (history.state) != 'object'){
        return true;
      }
      if(history.state.$$$id == null){
        return true;
      }
      let id = history.state.$$$id;
      if(!(id in this.$stateData)){
        return true;
      }
      return false;
    })();
    //------------------
    this._isStateExist();

    this._syncStateData();

    this.$event_onPopstate = this._getOnPopstateEvent();
    // this.$event_onPushstate = this._getOnPushstateEvent();
    const $event_init = this._getOnInitEvent(isNewPage);

    window.addEventListener('bbHistoryInit', $event_init);
    window.addEventListener('popstate', this.$event_onPopstate);
    // window.addEventListener('pushstate', this.$event_onPushstate);
    //------------------
    setTimeout(() => {
      debugger;
      let event = new Event('bbHistoryInit');
      window.dispatchEvent(event);
      window.removeEventListener('bbHistoryInit', $event_init);
    }, 0);
  }
  //--------------------------------------
  // API
  onPopstate(callback) {
    const eventName = 'popstate';

    const eventList = this['$events'][eventName];
    eventList.push(callback);
  }
  //--------------------------------------
  // API
  onPushstate(callback) {
    const eventName = 'pushstate';

    const eventList = this['$events'][eventName];
    eventList.push(callback);
  }
  //--------------------------------------
  // API
  setStateData(key, data) {
    debugger;

    if (this.$stateData.$current_stateID == null) {
      this.$stateData.$current_stateID = {};
    }
    const sData = this.$stateData.$current_stateID;
    sData[key] = data;
  }
  //--------------------------------------
  // API
  getStateData(key) {
    debugger;

    const sData = this.$stateData.$current_stateID;
    if (sData == null) {
      return null;
    }
    let res = (sData[key] != null) ? sData[key] : null;
    return res;
  }
  //--------------------------------------
  // API
  getPrevStateData(key) {
    debugger;

    const sData = this.$stateData.$prev_stateID;
    if (sData == null) {
      return null;
    }
    let res = (sData[key] != null) ? sData[key] : null;
    return res;
  }
  //--------------------------------------
  // API 改變 URL
  pushState(url) {
    // ++this.$emitCount;
    $sys.$history.pushState(null, null, url);
  }
  //--------------------------------------
  // listen onPopstate event
  _getOnPopstateEvent() {
    return (e) => {
      debugger;

      // 重點
      let eData = this._eventCheck(e);

      this._callListener('popstate', eData);
    };
  }
  //--------------------------------------
  // listen onPushstate event
  _getOnPushstateEvent() {
    return (e) => {
      debugger;

      // 重點
      let eData = this._eventCheck(e);

      this._callListener('pushstate', eData);
    };
  }
  //--------------------------------------
  // bbHistory 剛建構
  _getOnInitEvent(isNewPage){
    return (e) => {
      debugger;

      let eData = {
        isNewPage,
        direction: 1,
        currentID: (this.$current_stateID),
        prevID: (this.$prev_stateID),
      };

      this._callListener('popstate', eData);
    };
  }
  //--------------------------------------
  // 重點
  // 重點
  // 重點
  _eventCheck(e) {
    debugger;

    const data = {
      isNewPage: false,
      direction: 0,
      currentID: null,
      prevID: null,
    };

    if (history.state == null ||
      typeof (history.state) != 'object' ||
      history.state.$$$id == null) {

      // 全新的前進
      // 不是 history 的操作

      this._isStateExist();

      this._syncStateData();

      this._checkStateData_2(this.$prev_stateID, this.$current_stateID);

      data.isNewPage = true;
    } else {
      // history 的操作 [back|forword]

      this._syncStateData();
    }

    data.currentID = this.$current_stateID;
    data.prevID = this.$prev_stateID;

    let subtract = data.currentID - data.prevID;

    if (subtract > 0) {
      data.direction = 1;
    } else if (subtract < 0) {
      data.direction = -1;
    }

    return data;
  }
  //--------------------------------------
  _sysInit() {
    // debugger;

    if ($sys.$history == null) {
      $sys.$history = initHistory();
    }
  }
  //--------------------------------------
  _isStateExist() {
    debugger;

    if (history.state != null &&
      typeof (history.state) == 'object' && history.state.$$$id != null) {
      return;
    }

    console.log('history.state 不存在，建立');

    let id = this._getId();
    history.replaceState({
      '$$$id': id
    }, null);
  }
  //--------------------------------------
  // 記錄 $stateData
  _pushStateData(key, value = {}, replaceAll = false) {

    const sData = this.$stateData;

    if (replaceAll) {
      sData[key] = Object.assign({}, value);
      return;
    }
    sData[key] = Object.assign({}, sData[key], value);

  }
  //--------------------------------------
  // 同步(history.state | stateData) 資料
  //
  // 因應 reload，history.state 有資料
  _syncStateData() {
    debugger;

    const id = history.state.$$$id;

    this.$prev_stateID = (this.$current_stateID == null ?
      null : this.$current_stateID);

    this.$current_stateID = id;

    if (!(id in this.$stateData)) {
      // 同步資料

      this._pushStateData(id, {}, true);
    }
  }
  //--------------------------------------
  _checkStateData_2(old_id, new_id) {

    const sData = this.$stateData;

    if (!(new_id in sData)) {
      this._pushStateData(new_id, {});
    }

    let keyList = Object.keys(sData);

    keyList.forEach((id) => {
      // 重要的演算法
      if (id > old_id && id < new_id) {
        delete (sData[id]);
      }
    });
  }
  //--------------------------------------
  _getId() {
    return (new Date()).getTime();
  }
  //--------------------------------------
  //
  _callListener(eventName, eData) {
    const $events = this.$events;

    const eventList = $events[eventName];

    // 暫時
    eventList.forEach((handle) => {
      debugger;

      handle.call(this, eData);
    });

  }
}
////////////////////////////////////////////////////////////////////////////////


function initHistory() {
  const history_proto = Object.getPrototypeOf(history);

  // 繼承 history
  const $history = Object.create(history);
  const pushState_fn = history_proto.pushState;

  // 覆寫方法
  $history.pushState = function (...args) {

    let res = pushState_fn.apply(history, args);
    let event = new Event('popstate');
    window.dispatchEvent(event);

    return res;
  }
  return $history;
}
//-------------------------------------------
