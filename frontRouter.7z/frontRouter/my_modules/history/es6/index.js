'use strict';
import $GM from './g_module.js';

import f_db from './db/db.js';
$GM.import('HistoryDB', f_db($GM));

import f_history from './history.js';
$GM.import('historyModule', f_history($GM));

export default function (gm) {
  $GM.setParent(gm);

  const historyModule = $GM.get('historyModule');
  return historyModule;
};
