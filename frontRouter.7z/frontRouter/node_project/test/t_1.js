/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

let d = {
	$a: 'xyz',
	['$b']: 'cc'
};

console.dir(d);
console.log(d.$a);

